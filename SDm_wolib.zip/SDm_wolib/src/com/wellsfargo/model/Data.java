package com.wellsfargo.model;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class Data implements Serializable{


   private static final long serialVersionUID = -9102680678742495037L;

	@Column(name="IP_Address_Num")
	private String ip_address_num;
	
	@Column(name="IP_V6_Address")
	private String ip_v6_address;
	
	@Column(name="Create_date")
	private String create_date;
	
	@Column(name="PT_Cust_ID")
	protected String pt_cust_id;

	@Column(name="PT_Oper_ID")
	private String pt_oper_id;
	

	@Column(name="Start_Date")
	private String start_date;
	

	@Column(name="End_Date")
	private String end_date;
	
	@Column(name="IP_range")
	private String ip_range;
	
	@Column(name="IP_CIDR")
	private String ip_cidr;
	
	@Column(name="WAM_ID")
	private String wam_id;
	
	@Column(name="App_URL")
	private String app_url;
	
	@Column(name="App_Name")
	private String app_name;
	
	@Column(name="App_Type")
	private String app_type;
	
	@Column(name="IP_Address")
	private String ip_address;
	
	@Column(name="HostName")
	private String hostname;
	
	@Column(name="Contact_Names")
	private String contact_names;
	
	@Column(name="Dhcp_or_Static")
	private String dhcp_or_static;
	
	@Column(name="Created_By")
	private String created_by;
	
	@Column(name="Modified_By")
	private String modified_by;
	
	@Column(name="Email_Address")
	private String email_address;
	
	@Column(name="Phone_Number")
	private String phone_number;
	
	@Column(name="Notes")
	private String notes;
	
	@Column(name="Status")
	private String status;
	

	public String getIp_address_num() {
		return ip_address_num;
	}
	public void setIp_address_num(String ip_address_num) {
		this.ip_address_num = ip_address_num;
	}
	public String getIp_v6_address() {
		return ip_v6_address;
	}
	public void setIp_v6_address(String ip_v6_address) {
		this.ip_v6_address = ip_v6_address;
	}
	public String getCreate_date() {
		return create_date;
	}
	public void setCreate_date(String create_date) {
		this.create_date = create_date;
	}
	public String getPt_cust_id() {
		return pt_cust_id;
	}
	public void setPt_cust_id(String pt_cust_id) {
		this.pt_cust_id = pt_cust_id;
	}
	public String getPt_oper_id() {
		return pt_oper_id;
	}
	public void setPt_oper_id(String pt_oper_id) {
		this.pt_oper_id = pt_oper_id;
	}
	public String getStart_date() {
		return start_date;
	}
	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}
	public String getEnd_date() {
		return end_date;
	}
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	public String getIp_range() {
		return ip_range;
	}
	public void setIp_range(String ip_range) {
		this.ip_range = ip_range;
	}
	public String getIp_cidr() {
		return ip_cidr;
	}
	public void setIp_cidr(String ip_cidr) {
		this.ip_cidr = ip_cidr;
	}
	public String getWam_id() {
		return wam_id;
	}
	public void setWam_id(String wam_id) {
		this.wam_id = wam_id;
	}
	public String getApp_url() {
		return app_url;
	}
	public void setApp_url(String app_url) {
		this.app_url = app_url;
	}
	public String getApp_name() {
		return app_name;
	}
	public void setApp_name(String app_name) {
		this.app_name = app_name;
	}
	public String getApp_type() {
		return app_type;
	}
	public void setApp_type(String app_type) {
		this.app_type = app_type;
	}
	public String getIp_address() {
		return ip_address;
	}
	public void setIp_address(String ip_address) {
		this.ip_address = ip_address;
	}
	public String getHostname() {
		return hostname;
	}
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	public String getContact_names() {
		return contact_names;
	}
	public void setContact_names(String contact_names) {
		this.contact_names = contact_names;
	}
	public String getDhcp_or_static() {
		return dhcp_or_static;
	}
	public void setDhcp_or_static(String dhcp_or_static) {
		this.dhcp_or_static = dhcp_or_static;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}
	public String getEmail_address() {
		return email_address;
	}
	public void setEmail_address(String email_address) {
		this.email_address = email_address;
	}
	public String getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

}