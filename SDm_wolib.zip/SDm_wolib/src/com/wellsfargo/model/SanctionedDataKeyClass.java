package com.wellsfargo.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.SequenceGenerator;

@Embeddable
public class SanctionedDataKeyClass implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7829029953669794051L;

	@SequenceGenerator(name = "ss_approved_lst_seq", sequenceName = "WAF_SSA.SS_APPROVED_LST_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ss_approved_lst_seq")
	@Column(name = "ID", unique = true, nullable = false)
	private Long DT_RowId;
	
	@Column(name="PT_Cust_ID")
	private String pt_cust_id;
	
	@Column(name="Start_Date")
	private String start_date;
	
	@Column(name="End_Date")
	private String end_date;

	public Long getDT_RowId() {
		return DT_RowId;
	}

	public void setDT_RowId(Long dT_RowId) {
		DT_RowId = dT_RowId;
	}

	public String getPt_cust_id() {
		return pt_cust_id;
	}

	public void setPt_cust_id(String pt_cust_id) {
		this.pt_cust_id = pt_cust_id;
	}

	public String getStart_date() {
		return start_date;
	}

	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}

	public String getEnd_date() {
		return end_date;
	}

	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	
	
	
}
