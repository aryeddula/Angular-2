/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */
package com.wellsfargo.model;
/*
 * Table containing unsanctioned data
 * 
 * @Author: Ashok
 * @Version: 1.1
 * @Created on: 5/22/2017
 * 
 */

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@Table(name = "SS_UNAPPROVED_LST", schema = "WAF_SSA")
/*@NamedNativeQueries({
		@NamedNativeQuery(name = "@SQL_DELETE_BETWEEN_DATES_UNSANCTIONEDDATA", query = "delete from WAF_SSA.SS_UNAPPROVED_LST where Status = :status and Start_Date between :stDate and :edDate") })*/
public class UnsanctionedData extends Data implements Serializable{
	private static final long serialVersionUID = 5007373775683515553L;

	@Id
	@SequenceGenerator(name = "ss_unapproved_lst_seq", sequenceName = "WAF_SSA.SS_UNAPPROVED_LST_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ss_unapproved_lst_seq")
	@Column(name = "ID", unique = true, nullable = false)
	private Long DT_RowId;

	public Long getDT_RowId() {
		return DT_RowId;
	}

	public void setDT_RowId(Long DT_RowId) {
		this.DT_RowId = DT_RowId;
	}
}
