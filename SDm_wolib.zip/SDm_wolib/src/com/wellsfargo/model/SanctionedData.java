/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */

package com.wellsfargo.model;

/*
 * Table containing sanctioned data
 * 
 * @Author: Ashok
 * @Version: 1.1
 * @Created on: 5/22/2017
 * 
 */
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@Table(name = "SS_APPROVED_LST", schema = "WAF_SSA")
/*@NamedNativeQueries({
		@NamedNativeQuery(name = "@SQL_DELETE_BETWEEN_DATES_SANCTIONEDDATA", query = "delete from WAF_SSA.SS_APPROVED_LST where Status = :status and Start_Date between :stDate and :edDate "),
		@NamedNativeQuery(name = "@SQL_SELECT_SANCTIONEDDATA", query = "SELECT * from SS_APPROVED_LST a where a.CREATE_DATE in (select max(b.CREATE_DATE)  from SS_APPROVED_LST b where b.PT_CUST_ID= a.PT_CUST_ID)")})*/
public class SanctionedData extends Data {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6898226531304102770L;
	@Id
	@SequenceGenerator(name = "ss_approved_lst_seq", sequenceName = "WAF_SSA.SS_APPROVED_LST_SEQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ss_approved_lst_seq")
	@Column(name = "ID", nullable = true)
	private Long DT_RowId;

	public Long getDT_RowId() {
		return DT_RowId;
	}

	public void setDT_RowId(Long value) {	
		this.DT_RowId = value;
	}

}
