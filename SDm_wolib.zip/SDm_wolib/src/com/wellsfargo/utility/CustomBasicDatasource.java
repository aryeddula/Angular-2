package com.wellsfargo.utility;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.commons.codec.binary.Base64;
public class CustomBasicDatasource extends BasicDataSource{

    public CustomBasicDatasource() {
        super();
    }

    public synchronized void setPassword(String encodedPassword){
        this.password = decode(encodedPassword);
    }

    private String decode(String password) {
    return new String(Base64.decodeBase64(password));
    }
    
      
}

