/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */
package com.wellsfargo.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate4.support.HibernateDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.wellsfargo.model.SanctionedData;
import com.wellsfargo.model.UnsanctionedData;

@Repository("sdmDAO")
public class SDMDAOImpl extends HibernateDaoSupport implements SDMDAO {

	private static final Logger logger = LoggerFactory.getLogger(SDMDAOImpl.class);

	/*
	 * Retrieves the sanctioned data
	 * 
	 * @param (non-Javadoc)
	 * 
	 * @see com.wellsfargo.dao.SDMDAO#fetchSancData(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
/*	@Async*/
	@Transactional(value = "transactionManager", propagation = Propagation.REQUIRED, readOnly = true)
	public List<SanctionedData> fetchSancData() {
		logger.info("Inside DAO fetchSancData:");
		List<SanctionedData> sancData;
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		logger.info("Begin transaction:");
		try {
			String fetchAll = "from SanctionedData  where Start_Date between :stDate and :edDate";
			/*String fetchAll = "from SanctionedData a where a.create_date in (select max(b.create_date)  from SanctionedData b where b.PT_Cust_ID= a.PT_Cust_ID)";*/
			
			Query query = session.createQuery(fetchAll);
			query.setString("stDate", "00/00/0000");
			query.setString("edDate", "99/99/9999");
			query.setCacheable(true);
			query.setCacheRegion("sanctioneddata");
			sancData = query.list();
			session.getTransaction().commit();
			logger.info("Transaction Committed:");
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			logger.info("Transaction rolledback:");
			throw e; // or display error message
		} finally {
			session.close();
			logger.info("Session Closed:");
		}
		return sancData;
	}

	/*
	 * Retrieves the unsanctioned data
	 * 
	 * 
	 * (non-Javadoc)
	 * 
	 * @see com.wellsfargo.dao.SDMDAO#fetchUnsancData(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
/*	@Async*/
	@Transactional(value = "transactionManager", propagation = Propagation.REQUIRED, readOnly = true)
	public List<UnsanctionedData> fetchUnsancData() {
		logger.info("Inside DAO fetchUnsancData:");
		List<UnsanctionedData> unsancData;
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		Transaction tx = session.beginTransaction();
		logger.info("Begin transaction:");
		try {
			String fetchAll = "from UnsanctionedData where Start_Date between :stDate and :edDate";
			Query query = session.createQuery(fetchAll);
			query.setString("stDate", "00/00/0000");
			query.setString("edDate", "99/99/9999");
			query.setCacheable(true);
			query.setCacheRegion("unsanctioneddata");
			unsancData = query.list();
			session.getTransaction().commit();
			logger.info("Transaction Committed:");
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			logger.info("Transaction rolledback:");
			throw e; // or display error message
		} finally {
			session.close();
			logger.info("Session Closed:");
		}
		return unsancData;
	}

	/*
	 * 
	 * 
	 * (non-Javadoc)
	 * 
	 * @see com.wellsfargo.dao.SDMDAO#saveSancData(java.util.List,
	 * java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(value = "transactionManager", propagation = Propagation.REQUIRED, readOnly = false)
	public int saveSancData(List<SanctionedData> sanc_dataList, String loadType) {
		List<SanctionedData> sancDataDuplicate;
		logger.info("Inside DAO saveSancData:");
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		logger.info("Session Opened:");
		Transaction tx = session.beginTransaction();
		logger.info("Begin transaction:");
		try {
			for (SanctionedData sancData : sanc_dataList) {
				String fetchDuplicate = "from SanctionedData where ip_address_num = :ip_address_num and pt_cust_id = :pt_cust_id and start_date = :start_date and end_date = :end_date and app_name =:app_name and app_type =:app_type";
				Query query = session.createQuery(fetchDuplicate);
				query.setString("ip_address_num", sancData.getIp_address_num());
				query.setString("pt_cust_id", sancData.getPt_cust_id());
				query.setString("start_date", sancData.getStart_date());
				query.setString("end_date", sancData.getEnd_date());
				query.setString("app_name", sancData.getApp_name());
				query.setString("app_type", sancData.getApp_type());
				query.setCacheable(true);
				query.setCacheRegion("sanctioneddata");
				sancDataDuplicate = query.list();

				if (sancDataDuplicate.size() != 0) {
					logger.info("Duplicate Entry Ignored:");
					for (SanctionedData sancDataD : sancDataDuplicate)
						sancData.setDT_RowId(sancDataD.getDT_RowId());
				}
					session.merge(sancData);
			}
			session.getTransaction().commit();
			logger.info("Transaction commited:");
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			logger.info("Transaction rolledback:");
			throw e; // or display error message
		} finally {
			session.flush();
			session.clear();
			session.close();
			logger.info("Session closed:");
		}
		return 0;
	}

	/*
	 * 
	 * 
	 * (non-Javadoc)
	 * 
	 * @see com.wellsfargo.dao.SDMDAO#saveUnsancData(java.util.List,
	 * java.lang.String)
	 */
	@Override
	@Transactional(value = "transactionManager", propagation = Propagation.REQUIRED, readOnly = false)
	public int saveUnsancData(List<UnsanctionedData> unsanc_dataList, String loadType) {
	/*	List<UnsanctionedData> unsancDataDuplicate;*/
		logger.info("Inside DAO saveUnsancData:");
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		logger.info("Session Opened:");
		Transaction tx = session.beginTransaction();
		logger.info("Begin transaction:");
		try {
			for (UnsanctionedData unsancData : unsanc_dataList) {
				/*String fetchDuplicate = "from UnsanctionedData where ip_address_num = :ip_address_num and pt_cust_id = :pt_cust_id and start_date = :start_date and end_date = :end_date and app_name =:app_name and app_type =:app_type";
				Query query = session.createQuery(fetchDuplicate);
				query.setString("ip_address_num", unsancData.getIp_address_num());
				query.setString("pt_cust_id", unsancData.getPt_cust_id());
				query.setString("start_date", unsancData.getStart_date());
				query.setString("end_date", unsancData.getEnd_date());
				query.setString("app_name", unsancData.getApp_name());
				query.setString("app_type", unsancData.getApp_type());
				query.setCacheable(true);
				query.setCacheRegion("unsanctioneddata");
				unsancDataDuplicate = query.list();
				if (unsancDataDuplicate.size() != 0) {
					logger.info("Duplicate Entry Ignored:");
					for (UnsanctionedData unsancDataD : unsancDataDuplicate)
					unsancData.setDT_RowId(unsancDataD.getDT_RowId());
				}*/

					session.merge(unsancData);	
				}

			session.getTransaction().commit();
			logger.info("Transaction commited:");
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			logger.info("Transaction rolledback:");
			throw e; // or display error message
		} finally {
			session.flush();
			session.clear();
			session.close();
			logger.info("Session closed:");
		}
		return 0;
	}

	/*
	 * 
	 * 
	 * (non-Javadoc)
	 * 
	 * @see com.wellsfargo.dao.SDMDAO#deleteSancData(java.util.List)
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void deleteSancData(List<SanctionedData> sanc_dataList) {
		logger.info("Entered into deleteSancData:");
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		logger.info("Session Opened:");
		Transaction tx = session.beginTransaction();
		logger.info("Begin transaction:");
		try {
			for (SanctionedData sancData : sanc_dataList) {
				String deleteAllQ = "delete from SanctionedData where DT_RowId=:DT_RowId";
				Query query = session.createQuery(deleteAllQ);
				query.setLong("DT_RowId", sancData.getDT_RowId());
				query.executeUpdate();
			}
			session.getTransaction().commit();
			logger.info("Transaction commited:");
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			logger.info("Transaction rolledback:");
			throw e; // or display error message
		} finally {
			session.flush();
			session.clear();
			session.close();
			logger.info("Session closed:");
		}
	}

	/*
	 * 
	 * 
	 * (non-Javadoc)
	 * 
	 * @see com.wellsfargo.dao.SDMDAO#deleteUnsancData(java.util.List)
	 */
	@Override
	@Transactional(value = "transactionManager", propagation = Propagation.REQUIRED, readOnly = false)
	public void deleteUnsancData(List<UnsanctionedData> unsanc_dataList) {
		logger.info("Entered into deleteUnsancData:");
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		logger.info("Session Opened:");
		Transaction tx = session.beginTransaction();
		logger.info("Begin transaction:");
		try {
			for (UnsanctionedData unsancData : unsanc_dataList) {
				String deleteAllQ = "delete from UnsanctionedData where DT_RowId=:DT_RowId";
				Query query = session.createQuery(deleteAllQ);
				query.setLong("DT_RowId", unsancData.getDT_RowId());
				query.executeUpdate();
			}
			session.getTransaction().commit();
			logger.info("Transaction commited:");
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			logger.info("Transaction rolledback:");
			throw e; // or display error message
		} finally {
			session.flush();
			session.clear();
			session.close();
			logger.info("Session closed:");
		}

	}

	/*
	 * 
	 * 
	 * 
	 * (non-Javadoc)
	 * 
	 * @see com.wellsfargo.dao.SDMDAO#deleteDataViaDateRange(java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String)
	 */

	@SuppressWarnings("unchecked")
	@Override
/*	@Async*/
	@Transactional(value = "transactionManager", propagation = Propagation.REQUIRED, readOnly = true)
	public List<SanctionedData> fetchSancDataViaDateRange(String fetchType, String status, String stDate,
			String edDate) {
		logger.info("Entered into deleteSancDataViaDateRange:");
		List<SanctionedData> sancData;
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		logger.info("Session Opened:");
		Transaction tx = session.beginTransaction();
		logger.info("Begin transaction:");
		try {
			String fetchAll = "from SanctionedData where Start_Date between :stDate and :edDate";
			Query query = session.createQuery(fetchAll);
			query.setString("stDate", stDate);
			query.setString("edDate", edDate);
			/*query.setMaxResults(1500);*/
			/*query.setString("status", status);*/
			query.setCacheable(true);
			query.setCacheRegion("sanctioneddata");
			sancData = query.list();
			session.getTransaction().commit();
			logger.info("Transaction commited:");
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			logger.info("Transaction rolledback:");
			throw e; // or display error message
		} finally {
			session.flush();
			session.clear();
			session.close();
			logger.info("Session closed:");
		}

		return sancData;
	}

	@Override
	@Transactional(value = "transactionManager", propagation = Propagation.REQUIRED, readOnly = false)
	public int deleteSancDataViaDateRange(String fetchType, String status, String stDate, String edDate, List<UnsanctionedData> unsanc_dataList ) {
		logger.info("Entered into deleteSancDataViaDateRange:");
		int delRowsCount;
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		logger.info("Session Opened:");
		Transaction tx = session.beginTransaction();
		logger.info("Begin transaction:");
		Query query;
		try {
/*			Query query = session.getNamedQuery("@SQL_DELETE_BETWEEN_DATES_SANCTIONEDDATA").setString("status", status)
					.setString("stDate", stDate).setString("edDate", edDate);*/
			String deleteAllQ = "delete from SanctionedData where Start_Date between :stDate and :edDate";
			query = session.createQuery(deleteAllQ);
			query.setString("stDate", stDate);
			query.setString("edDate", edDate);
			/*query.setMaxResults(1500);*/
			delRowsCount = query.executeUpdate();
			for(UnsanctionedData unsanc: unsanc_dataList){
			session.merge(unsanc);
			}
			session.getTransaction().commit();
			logger.info("Transaction commited:");
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			logger.info("Transaction rolledback:");
			throw e; // or display error message
		} finally {
			session.flush();
			session.clear();
			session.close();
			logger.info("Session closed:");
		}

		return delRowsCount;
	}

	/*
	 * 
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.wellsfargo.dao.SDMDAO#deleteUnsancDataViaDateRange(java.lang.String,
	 * java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	@Transactional(value = "transactionManager", propagation = Propagation.REQUIRED, readOnly = false)
	public int deleteUnsancDataViaDateRange(String fetchType, String status, String stDate, String edDate) {
		logger.info("Entered into deleteUnsancDataViaDateRange:");
		int delRowsCount;
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		logger.info("Session Opened:");
		Transaction tx = session.beginTransaction();
		logger.info("Begin transaction:");
		Query query;
		try {
/*			query = session.getNamedQuery("@SQL_DELETE_BETWEEN_DATES_UNSANCTIONEDDATA").setString("status", status)
					.setString("stDate", stDate).setString("edDate", edDate);*/
			String deleteAllQ = "delete from UnsanctionedData where Start_Date between :stDate and :edDate";
			query = session.createQuery(deleteAllQ);
			query.setString("stDate", stDate);
			query.setString("edDate", edDate);
			delRowsCount = query.executeUpdate();
			session.getTransaction().commit();
			logger.info("Transaction commited:");
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			logger.info("Transaction rolledback:");
			throw e; // or display error message
		} finally {
			session.flush();
			session.clear();
			session.close();
			logger.info("Session closed:");
		}

		return delRowsCount;
	}

	/*
	 * 
	 * 
	 * 
	 * (non-Javadoc)
	 * 
	 * @see com.wellsfargo.dao.SDMDAO#updateSancData(java.util.List)
	 */
	@Override
	@Transactional(value = "transactionManager", propagation = Propagation.REQUIRED, readOnly = false)
	public String updateSancData(List<SanctionedData> sanc_dataList) {
		logger.info("Inside DAO updateSancData:");
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		logger.info("Session Opened:");
		Transaction tx = session.beginTransaction();
		logger.info("Begin transaction:");
		try {
			for (SanctionedData sancData : sanc_dataList) {
				session.merge(sancData);
			}
			session.getTransaction().commit();
			logger.info("Transaction commited:");
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			logger.info("Transaction rolledback:");
			throw e; // or display error message
		} finally {
			session.flush();
			session.clear();
			session.close();
			logger.info("Session closed:");
		}
		return null;
	}

	/*
	 * 
	 * 
	 * (non-Javadoc)
	 * 
	 * @see com.wellsfargo.dao.SDMDAO#updateUnsancData(java.util.List)
	 */
	@Override
	@Transactional(value = "transactionManager", propagation = Propagation.REQUIRED, readOnly = false)
	public String updateUnsancData(List<UnsanctionedData> unsanc_dataList) {
		logger.info("Inside DAO updateUnsancData:");
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		logger.info("Session Opened:");
		Transaction tx = session.beginTransaction();
		logger.info("Begin transaction:");
		try {
			for (UnsanctionedData unsancData : unsanc_dataList) {
				session.merge(unsancData);
			}
			session.getTransaction().commit();
			logger.info("Transaction commited:");
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			logger.info("Transaction rolledback:");
			throw e; // or display error message
		} finally {
			session.flush();
			session.clear();
			session.close();
			logger.info("Session closed:");
		}
		return null;
	}

	/*
	 * load the sanctioned data into sanctioned data table
	 * 
	 * @param sanc_dataList List that represents the sanctioned data
	 * (non-Javadoc)
	 * 
	 * @see com.wellsfargo.dao.SDMDAO#loadSancData(java.util.List)
	 */
	@Override
	@Transactional(value = "transactionManager", propagation = Propagation.REQUIRED, readOnly = false)
	public synchronized void loadSancData(List<SanctionedData> sanc_dataList) {
		logger.info("Inside DAO loadSancData:");
		int i = 0;
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		logger.info("Session Opened:");
		Transaction tx = session.beginTransaction();
		logger.info("Begin transaction:");
		try {
			for (SanctionedData sancData : sanc_dataList) {
				
					session.merge(sancData);
					i++;
					if (i % 50 == 0) {
						session.flush();
						session.clear();
					}
				}
			session.getTransaction().commit();
			logger.info("Transaction commited:");
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			logger.info("Transaction rolledback:");
			throw e; // or display error message
		} finally {
			session.flush();
			session.clear();
			session.close();
			logger.info("Session closed:");
		}
	}

	/*
	 * load the unsanctioned data into unsanctioned data table
	 * 
	 * @param unsanc_dataList List that represents the unsanctioned data
	 * (non-Javadoc)
	 * 
	 * @see com.wellsfargo.dao.SDMDAO#loadunsancData(java.util.List)
	 */
	@Override
	@Transactional(value = "transactionManager", propagation = Propagation.REQUIRED, readOnly = false)
	public synchronized void loadunsancData(List<UnsanctionedData> unsanc_dataList) {
		logger.info("Inside DAO loadUnsancData:");
		int i = 0;
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		logger.info("Session Opened:");
		Transaction tx = session.beginTransaction();
		logger.info("Begin transaction:");
		try {
			for (UnsanctionedData unsancData : unsanc_dataList) {
				session.merge(unsancData);
				i++;
				if (i % 50 == 0) {
					session.flush();
					session.clear();
				}
			}
			session.getTransaction().commit();
			logger.info("Transaction commited:");
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			logger.info("Transaction rolledback:");
			throw e; // or display error message
		} finally {
			session.flush();
			session.clear();
			session.close();
			logger.info("Session closed:");
		}
	}

	//Backdoor delete for developer database cleanup
	@Override
	@Transactional(value = "transactionManager", propagation = Propagation.REQUIRED, readOnly = false)
	public void sancdeleteAll() {
		logger.info("Entered into deleteUnsancData:");
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		logger.info("Session Opened:");
		Transaction tx = session.beginTransaction();
		logger.info("Begin transaction:");
		try {
			String deleteAllQ = "delete from SanctionedData";
			Query query = session.createQuery(deleteAllQ);
			query.executeUpdate();
			session.getTransaction().commit();
			logger.info("Transaction commited:");
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			logger.info("Transaction rolledback:");
			throw e; // or display error message
		} finally {
			session.flush();
			session.clear();
			session.close();
			logger.info("Session closed:");
		}

	}

	//Backdoor delete for developer database cleanup
	@Override
	@Transactional(value = "transactionManager", propagation = Propagation.REQUIRED, readOnly = false)
	public void unsancdeleteAll() {
		logger.info("Entered into deleteUnsancData:");
		Session session = getHibernateTemplate().getSessionFactory().openSession();
		logger.info("Session Opened:");
		Transaction tx = session.beginTransaction();
		logger.info("Begin transaction:");
		try {
			String deleteAllQ = "delete from UnsanctionedData";
			Query query = session.createQuery(deleteAllQ);
			query.executeUpdate();
			session.getTransaction().commit();
			logger.info("Transaction commited:");
		} catch (RuntimeException e) {
			if (tx != null)
				tx.rollback();
			logger.info("Transaction rolledback:");
			throw e; // or display error message
		} finally {
			session.flush();
			session.clear();
			session.close();
			logger.info("Session closed:");
		}

	}

}