/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */
package com.wellsfargo.dao;

/*
 * Cache enabled operations are performed
 * 
 * @Author: Ashok
 * @Version: 1.1
 * @Created on: 5/22/2017
 * 
 */
import java.util.List;

import com.wellsfargo.model.SanctionedData;
import com.wellsfargo.model.UnsanctionedData;

public interface SDMDAO {
	// Fetch sanctioned and unsanctioned data methods
	public List<SanctionedData> fetchSancData();

	public List<UnsanctionedData> fetchUnsancData();

	// Save sanctioned and unsanctioned data methods
	public int saveSancData(List<SanctionedData> sanc_dataList, String loadType);

	public int saveUnsancData(List<UnsanctionedData> unsanc_dataList, String loadType);

	// Delete sanctioned and unsanctioned data methods
	public void deleteSancData(List<SanctionedData> sanc_dataList);

	public void deleteUnsancData(List<UnsanctionedData> unsanc_dataList);

	// Delete sanctioned and unsanctioned data methods to delete the date b/t
	// date range
	public int deleteSancDataViaDateRange(String fetchType, String status, String stDate, String edDate, List<UnsanctionedData> unsanc_dataList);

	public int deleteUnsancDataViaDateRange(String fetchType, String status, String stDate, String edDate);

	// Update sanctioned and unsanctioned data methods
	public String updateSancData(List<SanctionedData> sanc_dataList);

	public String updateUnsancData(List<UnsanctionedData> unsanc_dataList);

	// Load sanctioned and unsanctioned data methods
	public void loadSancData(List<SanctionedData> sanc_dataList);

	public void loadunsancData(List<UnsanctionedData> sanc_dataList);

	public void sancdeleteAll();

	public void unsancdeleteAll();

	public List<SanctionedData> fetchSancDataViaDateRange(String fetchType, String status, String stDate,
			String edDate);

}