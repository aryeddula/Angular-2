/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */
package com.wellsfargo.controller;

/*
 * 
 * 
 * @Author: 
 * @Version: 1.1
 * @Created on: 5/22/2017
 * 
 */
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.wellsfargo.model.Response;
import com.wellsfargo.service.SDMService;

@RestController
@Scope("prototype")
public class SDMController {

	@Autowired(required = true)
	private SDMService sdmService;

	@Autowired(required = true)
	private Response response;

	private static final Logger logger = LoggerFactory.getLogger(SDMController.class);

	@ResponseBody
	@RequestMapping(value = "/loadData", method = RequestMethod.POST)
	public String loadData(@RequestParam("loadType") String loadType, @RequestParam("file") MultipartFile file) {
		logger.info("Inside loadData:");
		String tableName = loadType.substring(0, 1).toUpperCase() + loadType.substring(1);
		try {
			String fileName = file.getOriginalFilename();
			String fileType = fileName.substring(fileName.lastIndexOf(".") + 1).trim();
			InputStream is = file.getInputStream();
			int flag = sdmService.loadData(fileType, loadType, is);
			if(flag != 0 && flag != 2)
				response = populateResponse("203", "info", "Failed to load data into"+ " " + loadType
						+ " " + "table. Possible issues could be either invalid/duplicate data" , null);
			else
			response = populateResponse("200", "success", "Data loaded successfully into " + tableName + " table",
					null);
		} catch (Exception ex) {
			logger.error("Exception is: ", ex);
			response = populateResponse("204", "error",
					"Failed to load data into " + tableName + " table.<br/>"
							+ "Possible issues could be either invalid/corrupted data in excel sheet"
							+ "<br/>or backend connection failure.Verify logs for more details.<br/> "
							+ "<strong>Exception message : </strong>" + ex.getMessage(),
					null);
		}
		return new Gson().toJson(response);
	}

	@ResponseBody
	@RequestMapping(value = "/fetchData", method = RequestMethod.POST, headers = "Accept=application/json")
	public String fetchData(@RequestParam("fetchType") String fetchType) {
		logger.info("Inside fetchData:");
		String tableName = fetchType.substring(0, 1).toUpperCase() + fetchType.substring(1);
		try {
			List<?> dataList = sdmService.fetchData(fetchType);
			response.setStatusCode("200");
			response.setStatusText("success");
			response.setData(dataList);
		} catch (Exception ex) {
			logger.error("Exception is: ", ex);
			response = populateResponse("204", "error",
					"Sorry,failed to fetch data from " + tableName + " table.Exception message : " + ex.getMessage(),
					null);
		}
		return new Gson().toJson(response);
	}

	@ResponseBody
	@RequestMapping(value = "/manageData", method = RequestMethod.POST, headers = "Accept=application/json")
	public synchronized String manageData(@RequestBody MultiValueMap<String, String> formData) {
		logger.info("Inside manageData:");
		Map<String, String> map = formData.toSingleValueMap();
		String action = map.get("action");
		String fetchType = map.get("fetchType");
		String tableName = fetchType.substring(0, 1).toUpperCase() + fetchType.substring(1);
		if (action.equals("remove") && fetchType.equals("sanctioned")) {
			try {
				sdmService.deleteData(fetchType, map, action);
				sdmService.saveData("unsanctioned", map, action);
				response = populateResponse("200", "success",
						"Successfully deleted record(s) in " + tableName + " table", new ArrayList<>());
				return new Gson().toJson(response);
			} catch (Exception ex) {
				logger.error("Exception is: ", ex);
				response = populateResponse("204", "error", "Sorry,failed to delete data from " + tableName
						+ " table.Exception message : " + ex.getMessage(), null);
			}
		} else if (action.equals("remove") && fetchType.equals("unsanctioned")) {
			try {
				sdmService.deleteData(fetchType, map, action);
				response = populateResponse("200", "success",
						"Successfully deleted record(s) in " + tableName + " table", new ArrayList<>());
				return new Gson().toJson(response);
			} catch (Exception ex) {
				logger.error("Exception is: ", ex);
				response = populateResponse("204", "error", "Sorry,failed to delete data from " + tableName
						+ " table.Exception message : " + ex.getMessage(), null);
			}
		} else if (action.equals("create")) {
			try {
				List<?> dataList = sdmService.saveData(fetchType, map, action);
				response = populateResponse("200", "success",
						"Successfully deleted record(s) in " + tableName + " table", dataList);
				return new Gson().toJson(response);
			} catch (Exception ex) {
				logger.error("Exception is: ", ex);
				response = populateResponse("204", "error", "Sorry,failed to create data from " + tableName
						+ " table.Exception message : " + ex.getMessage(), null);
			}
		} else if (action.equals("edit")) {
			try {
				List<?> dataList = sdmService.updateData(fetchType, map, action);
				response = populateResponse("200", "success",
						"Successfully updated record(s) in " + tableName + " table", dataList);
				return new Gson().toJson(response);
			} catch (Exception ex) {
				logger.error("Exception is: ", ex);
				response = populateResponse("204", "error",
						"Sorry,failed to edit data from " + tableName + " table.Exception message : " + ex.getMessage(),
						null);
			}
		} else if (action.equals("deleteall")) {
			try {
				sdmService.deleteAll(fetchType);
				response.setStatusCode("200");
				response.setStatusText("success");
				response.setData(null);
			} catch (Exception ex) {
				logger.error("Exception is: ", ex);
				response = populateResponse("204", "error", "Sorry,failed to create data from " + tableName
						+ " table.Exception message : " + ex.getMessage(), null);
			}
		}
		return new Gson().toJson(response);

	}

	@ResponseBody
	@RequestMapping(value = "/dateRange", method = RequestMethod.POST)
	public String dateRange(@RequestParam("fetchType") String fetchType,
			@RequestParam("stDate") String stDate, @RequestParam("edDate") String edDate) {
		logger.info("Inside dateRange:");
		int delRowsCount = 0;
		try {
			delRowsCount = sdmService.deleteDataViaDateRange(fetchType, stDate, edDate);
			populateResponse("203", "info", "Couldn't delete any record from " + fetchType
					+ " table as there were no matching records found for this date range", null);
			if (delRowsCount > 0)
				if(fetchType.equalsIgnoreCase("sanctioned") )
				response = populateResponse("200", "success",
						delRowsCount + " records deleted successfully from " + fetchType + " table and inserted into unsanctioned table", null);
				else
					response = populateResponse("200", "success",
							delRowsCount + " records deleted successfully from " + fetchType + " table", null);
			else if (delRowsCount == 0)
				response = populateResponse("203", "info", "Couldn't delete any record from " + fetchType
						+ " table as there were no matching records found for this date range", null);
		} catch (Exception ex) {
			response = populateResponse("204", "error",
					"Sorry,failed to delete data from " + fetchType + " table.<br/>"
							+ "Possible issues could be backend connection failure.Verify logs for more details.<br/> "
							+ "<strong>Exception message : </strong>" + ex.getMessage(),
					null);
		}
		 return new Gson().toJson(response); 
	}

	private Response populateResponse(String statusCode, String statusText, String message, List<?> data) {

		response.setStatusCode(statusCode);
		response.setStatusText(statusText);
		response.setMessage(message);
		response.setData(data);
		return response;
	}

}
