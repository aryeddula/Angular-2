/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */

package com.wellsfargo.service;

/*
 * Service Impl
 * 
 * @Author: Ashok
 * @Version: 1.1
 * @Created on: 5/22/2017
 * 
 */
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import java.util.TreeMap;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.wellsfargo.dao.SDMDAO;
import com.wellsfargo.model.Data;
import com.wellsfargo.model.SanctionedData;
import com.wellsfargo.model.UnsanctionedData;

@Service("sdmService")
public class SDMServiceImpl implements SDMService {

	private static final Logger logger = LoggerFactory.getLogger(SDMServiceImpl.class);

	private SDMDAO sdmDAO;

	public void setSdmDAO(SDMDAO sdmDAO) {
		this.sdmDAO = sdmDAO;
	}

	/*
	 * @param fetchType that represents the fetch datatype
	 * 
	 * (non-Javadoc)
	 * 
	 * @see com.wellsfargo.service.SDMService#fetchData(java.lang.String)
	 */
	@Override
	public List<?> fetchData(String fetchType) {
		logger.info("Inside ServiceImpl fetchData:");
		if (fetchType.equals("sanctioned")) {
			logger.info("Sent DAOImpl fetchSancData:");
			return sdmDAO.fetchSancData();
		} else {
			logger.info("Sent DAOImpl fetchUnsancData:");
			return sdmDAO.fetchUnsancData();
		}
	}

	/*
	 * 
	 * 
	 * (non-Javadoc)
	 * 
	 * @see com.wellsfargo.service.SDMService#saveData(java.lang.String,
	 * java.util.Map)
	 */
	@SuppressWarnings("unused")
	@Override
	public List<?> saveData(String fetchType, Map<String, String> map, String action) {
		int flag = 0;
		logger.info("Inside ServiceImpl saveData:");
		if (fetchType.equals("sanctioned")) {
			@SuppressWarnings("unchecked")
			List<SanctionedData> sanc_dataList = (List<SanctionedData>) populateModel(fetchType, map, action);
			logger.info("Sent DAOImpl saveSancData:");
			if (!(sanc_dataList == null))
				flag = sdmDAO.saveSancData(sanc_dataList, fetchType);
			return sanc_dataList;
		} else {

			@SuppressWarnings("unchecked")
			List<UnsanctionedData> unsanc_dataList = (List<UnsanctionedData>) populateModel(fetchType, map, action);
			logger.info("Sent DAOImpl saveUnsancData:");
			if (!(unsanc_dataList == null))
				flag = sdmDAO.saveUnsancData(unsanc_dataList, fetchType);
			return unsanc_dataList;

		}
	}

	/*
	 * 
	 * 
	 */
	private List<?> populateModel(String fetchType, Map<String, String> map, String action) {
		List<SanctionedData> sancdataList = new ArrayList<SanctionedData>();
		List<UnsanctionedData> unsancdataList = new ArrayList<UnsanctionedData>();
		Map<String, String> sdataMap = new TreeMap<String, String>(map);

		Data data;

		int counter = 0;

		@SuppressWarnings("unused")
		boolean createUpdateFlag = false;

		boolean updateDelFlag = false;

		boolean delFlag = false;

		if (fetchType.equalsIgnoreCase("sanctioned"))
			data = new SanctionedData();
		else
			data = new UnsanctionedData();

		if (action.equalsIgnoreCase("create"))
			createUpdateFlag = true;

		if (action.equalsIgnoreCase("edit"))
			updateDelFlag = true;

		if (action.equalsIgnoreCase("remove"))
			delFlag = true;

		for (Entry<String, String> entry : sdataMap.entrySet()) {
			String key = entry.getKey();
			String value = (entry.getValue().length() == 0) ? " " : entry.getValue();

			if (!key.equalsIgnoreCase(
					"action")
					&& !key
							.equalsIgnoreCase(
									"fetchType")
					&& !key.substring(key.indexOf("[", key.indexOf("[") + 1) + 1, key.lastIndexOf("]"))
							.equalsIgnoreCase("DT_RowId")
					&& !key.substring(key.indexOf("[", key.indexOf("[") + 1) + 1, key.lastIndexOf("]"))
							.equalsIgnoreCase("status")) {

				if ((updateDelFlag == true || delFlag == true) && counter == 0) {
					if (fetchType.equalsIgnoreCase("sanctioned"))
						((SanctionedData) data)
								.setDT_RowId(Long.valueOf(key.substring(key.indexOf("[") + 1, key.indexOf("]"))));
					else
						((UnsanctionedData) data)
								.setDT_RowId(Long.valueOf(key.substring(key.indexOf("[") + 1, key.indexOf("]"))));
				}
				counter++;
				switch (key.substring(key.indexOf("[", key.indexOf("[") + 1) + 1, key.lastIndexOf("]"))) {
				case "ip_address_num":
					data.setIp_address_num(value);
					break;
				case "ip_v6_address":
					data.setIp_v6_address(value);
					break;
				case "create_date":
					data.setCreate_date(value);
					break;
				case "pt_cust_id":
					data.setPt_cust_id(value);
					break;
				case "pt_oper_id":
					data.setPt_oper_id(value);
					break;
				case "start_date":
					data.setStart_date(value);
					break;
				case "end_date":
					data.setEnd_date(value);
					break;
				case "ip_range":
					data.setIp_range(value);
					break;
				case "ip_cidr":
					data.setIp_cidr(value);
					break;
				case "wam_id":
					data.setWam_id(value);
					break;
				case "app_url":
					data.setApp_url(value);
					break;
				case "app_name":
					data.setApp_name(value);
					break;
				case "app_type":
					data.setApp_type(value);
					break;
				case "ip_address":
					data.setIp_address(value);
					break;
				case "hostname":
					data.setHostname(value);
					break;

				case "contact_names":
					data.setContact_names(value);
					break;

				case "dhcp_or_static":
					data.setDhcp_or_static(value);
					break;
				case "created_by":
					data.setCreated_by(value);
					break;
				case "modified_by":
					data.setModified_by(value);
					break;
				case "email_address":
					data.setEmail_address(value);
					break;
				case "phone_number":
					data.setPhone_number(value);
					break;
				case "notes":
					data.setNotes(value);
					break;
				}
				/* logger.info("Counter in populate model:" + counter); */
				if (counter == 22) {
					if (fetchType.equals("sanctioned")) {
						counter = 0;
						data.setStatus("Active");
						sancdataList.add((SanctionedData) data);
						data = new SanctionedData();
					} else if (fetchType.equals("unsanctioned")) {
						counter = 0;
						data.setStatus("InActive");
						unsancdataList.add((UnsanctionedData) data);
						data = new UnsanctionedData();
					}
				}

			}
		}
		if (fetchType.equals("sanctioned"))
			return sancdataList;
		else
			return unsancdataList;
	}

	/*
	 * Deletes the data from respective table and update it in neg. table
	 * 
	 * (non-Javadoc)
	 * 
	 * @see com.wellsfargo.service.SDMService#deleteData(java.lang.String,
	 * java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void deleteData(String fetchType, Map<String, String> map, String action) {
		logger.info("Inside ServiceImpl deleteData:");
		if (fetchType.equals("sanctioned")) {
			List<?> dataList = populateModel(fetchType, map, action);
			logger.info("Sent DAOImpl for deletion:");
			if (!(dataList == null))
				sdmDAO.deleteSancData((List<SanctionedData>) dataList);
		} else {
			List<?> dataList = populateModel(fetchType, map, action);
			logger.info("Sent DAOImpl for deletion:");
			if (!(dataList == null))
				sdmDAO.deleteUnsancData((List<UnsanctionedData>) dataList);
		}
	}

	/*
	 * Loads the data from xls file
	 * 
	 * @param fileType
	 * 
	 * @param loadType
	 * 
	 * @param is (non-Javadoc)
	 * 
	 * @see com.wellsfargo.service.SDMService#loadData(java.lang.String,
	 * java.lang.String, java.io.InputStream)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public int loadData(String fileType, String loadType, InputStream is) throws IOException {
		logger.info("Inside ServiceImpl loadData:");
		List<SanctionedData> sanc_dataList = new ArrayList<SanctionedData>();
		List<UnsanctionedData> unsanc_dataList = new ArrayList<UnsanctionedData>();
		List<SanctionedData> sanc_duplicateList = new ArrayList<SanctionedData>();
		List<UnsanctionedData> unsanc_duplicateList = new ArrayList<UnsanctionedData>();

		if (loadType.equalsIgnoreCase("sanctioned"))
			sanc_duplicateList = (List<SanctionedData>) readCache(loadType);
		else
			unsanc_duplicateList = (List<UnsanctionedData>) readCache(loadType);
		int flag = 0;
		int colindex = 0;
		// Using XSSF for xlsx format, for xls use HSSF
		Workbook workbook = null;
		/*
		 * if (fileType.equals("xls")) workbook = new HSSFWorkbook(is); else
		 */
		workbook = new XSSFWorkbook(is);

		int numberOfSheets = workbook.getNumberOfSheets();

		logger.info("looping over each workbook:");
		// looping over each workbook // sheet
		for (int i = 0; i < numberOfSheets; i++) {
			Sheet sheet = workbook.getSheetAt(i);
			Iterator<Row> rowIterator = sheet.iterator();

			logger.info("In row Iteration:");
			// iterating over each row
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();

				// skip first row, as that contains header
				if (row.getRowNum() == 0) {
					continue;
				}

				if (rowContainsValue(row, row.getFirstCellNum(), row.getLastCellNum())) {
					Data data = null;
					if (loadType.equals("sanctioned"))
						data = new SanctionedData();
					else
						data = new UnsanctionedData();

					Iterator<Cell> cellIterator = row.cellIterator();
					logger.info("Inside cell iteration:");
					while (cellIterator.hasNext()) {
						Cell cell = cellIterator.next();

						// Check the cell type and format accordingly
						switch (cell.getCellType()) {
						case Cell.CELL_TYPE_NUMERIC:
							logger.info(cell.getColumnIndex() + "->" + (int) cell.getNumericCellValue() + ",");
							break;
						case Cell.CELL_TYPE_STRING:
							logger.info(cell.getColumnIndex() + "->" + cell.getStringCellValue() + ",");
							break;

						}

						if (cell.getColumnIndex() == 0)
							data.setIp_address_num(cellContainsValue(cell) ? cellFormat(cell) : " ");
						else if (cell.getColumnIndex() == 1)
							data.setIp_v6_address(cellContainsValue(cell) ? cellFormat(cell) : " ");
						else if (cell.getColumnIndex() == 2)
							data.setCreate_date(cellContainsValue(cell) ? dateCellFormat(cell) : " ");
						else if (cell.getColumnIndex() == 3)
							data.setPt_cust_id(cellFormat(cell));
						else if (cell.getColumnIndex() == 4)
							data.setPt_oper_id(cellFormat(cell));
						else if (cell.getColumnIndex() == 5)
							data.setStart_date(cellContainsValue(cell) ? dateCellFormat(cell) : " ");
						else if (cell.getColumnIndex() == 6)
							data.setEnd_date(cellContainsValue(cell) ? dateCellFormat(cell) : " ");
						else if (cell.getColumnIndex() == 7)
							data.setIp_range(cellContainsValue(cell) ? cellFormat(cell) : " ");
						else if (cell.getColumnIndex() == 8)
							data.setIp_cidr(cellContainsValue(cell) ? cellFormat(cell) : " ");
						else if (cell.getColumnIndex() == 9)
							data.setWam_id(cellContainsValue(cell) ? cellFormat(cell) : " ");
						else if (cell.getColumnIndex() == 10)
							data.setApp_url(cellContainsValue(cell) ? cellFormat(cell) : " ");
						else if (cell.getColumnIndex() == 11)
							data.setApp_name(cellContainsValue(cell) ? cellFormat(cell) : " ");
						else if (cell.getColumnIndex() == 12)
							data.setApp_type(cellContainsValue(cell) ? cellFormat(cell) : " ");
						else if (cell.getColumnIndex() == 13)
							data.setIp_address(cellContainsValue(cell) ? cellFormat(cell) : " ");
						else if (cell.getColumnIndex() == 14)
							data.setHostname(cellContainsValue(cell) ? cellFormat(cell) : " ");
						else if (cell.getColumnIndex() == 15)
							data.setContact_names(cellContainsValue(cell) ? cellFormat(cell) : " ");
						else if (cell.getColumnIndex() == 16)
							data.setDhcp_or_static(cellContainsValue(cell) ? cellFormat(cell) : " ");
						else if (cell.getColumnIndex() == 17)
							data.setCreated_by(cellContainsValue(cell) ? cellFormat(cell) : " ");
						else if (cell.getColumnIndex() == 18)
							data.setModified_by(cellContainsValue(cell) ? cellFormat(cell) : " ");
						else if (cell.getColumnIndex() == 19)
							data.setEmail_address(cellContainsValue(cell) ? cellFormat(cell) : " ");
						else if (cell.getColumnIndex() == 20)
							data.setPhone_number(cellContainsValue(cell) ? cellFormat(cell) : " ");
						else if (cell.getColumnIndex() == 21)
							data.setNotes(cellContainsValue(cell) ? cellFormat(cell) : " ");

						colindex++;
						if (colindex == 21)
							colindex = 0;
					}
					if (loadType.equals("sanctioned")) {
						data.setStatus("Active");
						Data sanctiondata = (SanctionedData) formatData(data);
						if (checkDuplicateEntries(sanctiondata, sanc_duplicateList)) {
							if (flag == 0) {
								flag = 1;
							}
						} else {
							if (flag == 0 || flag == 1) {
								flag = 2;
							}
							sanc_dataList.add((SanctionedData) sanctiondata);
						}

					} else {
						data.setStatus("InActive");
						Data unsanctiondata = (UnsanctionedData) formatData(data);
						if (checkDuplicateEntries_unsanc(unsanctiondata, unsanc_duplicateList)) {
							if (flag == 0) {
								flag = 1;
							}

						} else {
							if (flag == 0 || flag == 1) {
								flag = 2;
							}
							unsanc_dataList.add((UnsanctionedData) unsanctiondata);
						}

					}
				}
			}
		}
		if (loadType.equals("sanctioned")) {
			logger.info("Sent to DAOImpl to save:");
			sdmDAO.loadSancData(sanc_dataList);
		} else {
			logger.info("Sent to DAOImpl to save:");
			sdmDAO.loadunsancData(unsanc_dataList);
		}
		return flag;
	}

	public Data formatData(Data data) {

		if (data.getCreate_date() == null)
			data.setCreate_date(" ");
		if (data.getPt_cust_id() == null)
			data.setPt_cust_id(" ");
		if (data.getIp_address_num() == null)
			data.setIp_address_num(" ");
		if (data.getIp_v6_address() == null)
			data.setIp_v6_address(" ");
		if (data.getPt_oper_id() == null)
			data.setPt_oper_id(" ");
		if (data.getStart_date() == null)
			data.setStart_date(" ");
		if (data.getEnd_date() == null)
			data.setEnd_date(" ");
		if (data.getIp_range() == null)
			data.setIp_range(" ");
		if (data.getIp_cidr() == null)
			data.setIp_cidr(" ");
		if (data.getWam_id() == null)
			data.setWam_id(" ");
		if (data.getApp_url() == null)
			data.setApp_url(" ");
		if (data.getApp_name() == null)
			data.setApp_name(" ");
		if (data.getApp_type() == null)
			data.setApp_type(" ");
		if (data.getIp_address() == null)
			data.setIp_address(" ");
		if (data.getHostname() == null)
			data.setHostname(" ");
		if (data.getContact_names() == null)
			data.setContact_names(" ");
		if (data.getDhcp_or_static() == null)
			data.setDhcp_or_static(" ");
		if (data.getCreated_by() == null)
			data.setCreated_by(" ");
		if (data.getModified_by() == null)
			data.setModified_by(" ");
		if (data.getEmail_address() == null)
			data.setEmail_address(" ");
		if (data.getPhone_number() == null)
			data.setPhone_number(" ");
		if (data.getNotes() == null)
			data.setNotes(" ");
		return data;

	}

	/*
	 * 
	 * 
	 * (non-Javadoc)
	 * 
	 * @see com.wellsfargo.service.SDMService#updateData(java.lang.String,
	 * java.util.Map)
	 */
	@Override
	public List<?> updateData(String fetchType, Map<String, String> map, String action) {
		logger.info("Inside ServiceImpl updateData:");
		if (fetchType.equals("sanctioned")) {
			@SuppressWarnings("unchecked")
			List<SanctionedData> sanc_dataList = (List<SanctionedData>) populateModel(fetchType, map, action);
			logger.info("Sent DAOImpl updateSancData:");
			if (!(sanc_dataList == null))
				sdmDAO.updateSancData(sanc_dataList);
			return sanc_dataList;
		} else {

			@SuppressWarnings("unchecked")
			List<UnsanctionedData> unsanc_dataList = (List<UnsanctionedData>) populateModel(fetchType, map, action);
			logger.info("Sent DAOImpl updateUnsancData:");
			if (!(unsanc_dataList == null))
				sdmDAO.updateUnsancData(unsanc_dataList);
			return unsanc_dataList;

		}
	}

	/*
	 * 
	 * 
	 * (non-Javadoc)
	 * 
	 * @see com.wellsfargo.service.SDMService#deleteDataViaDateRange(java.lang.
	 * String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public int deleteDataViaDateRange(String fetchType, String stDate, String edDate) {
		int delRowsCount = 0;
		if (fetchType.equals("sanctioned")) {
			List<SanctionedData> sancData = sdmDAO.fetchSancDataViaDateRange(fetchType, "Active", stDate, edDate);
			/* if(sancData.size() > 1500) */
			if (!(sancData == null))
				delRowsCount = sdmDAO.deleteSancDataViaDateRange(fetchType, "Active", stDate, edDate,
						sancConvertUnsac(sancData));
			/*
			 * if (!(delRowsCount == 0)) { List<UnsanctionedData> unsancdata =
			 * sancConvertUnsac(sancData); sdmDAO.saveUnsancData(unsancdata,
			 * fetchType); }
			 */
			return delRowsCount;
		} else {
			return sdmDAO.deleteUnsancDataViaDateRange(fetchType, "InActive", stDate, edDate);
		}
	}

	public List<UnsanctionedData> sancConvertUnsac(List<SanctionedData> sancData) {
		List<UnsanctionedData> unsancdata = new ArrayList<UnsanctionedData>();
		for (SanctionedData sanc : sancData) {
			UnsanctionedData data = new UnsanctionedData();
			data.setIp_address_num(sanc.getIp_address_num());
			data.setIp_v6_address(sanc.getIp_v6_address());
			data.setCreate_date(sanc.getCreate_date());
			data.setPt_cust_id(sanc.getPt_cust_id());
			data.setPt_oper_id(sanc.getPt_oper_id());
			data.setStart_date(sanc.getStart_date());
			data.setEnd_date(sanc.getEnd_date());
			data.setIp_range(sanc.getIp_range());
			data.setIp_cidr(sanc.getIp_cidr());
			data.setWam_id(sanc.getWam_id());
			data.setApp_url(sanc.getApp_url());
			data.setApp_name(sanc.getApp_name());
			data.setApp_type(sanc.getApp_type());
			data.setIp_address(sanc.getIp_address());
			data.setHostname(sanc.getHostname());
			data.setContact_names(sanc.getContact_names());
			data.setDhcp_or_static(sanc.getDhcp_or_static());
			data.setCreated_by(sanc.getCreated_by());
			data.setModified_by(sanc.getModified_by());
			data.setEmail_address(sanc.getEmail_address());
			data.setPhone_number(sanc.getPhone_number());
			data.setNotes(sanc.getNotes());
			data.setStatus("InActive");
			unsancdata.add(data);
		}
		return unsancdata;
	}

	/*
	 * Excel cells formating
	 * 
	 */
	private boolean rowContainsValue(Row row, int fcell, int lcell) {
		boolean flag = false;
		for (int i = fcell; i < lcell; i++) {
			if (StringUtils.isEmpty(String.valueOf(row.getCell(i))) == true
					|| StringUtils.isWhitespace(String.valueOf(row.getCell(i))) == true
					|| StringUtils.isBlank(String.valueOf(row.getCell(i))) == true
					|| String.valueOf(row.getCell(i)).length() == 0 || row.getCell(i) == null) {
			} else {
				flag = true;
			}
		}
		return flag;
	}

	private boolean cellContainsValue(Cell cell) {
		boolean flag = false;
		if (StringUtils.isEmpty(String.valueOf(cell)) == true || StringUtils.isWhitespace(String.valueOf(cell)) == true
				|| StringUtils.isBlank(String.valueOf(cell)) == true || String.valueOf(cell).length() == 0
				|| cell == null) {
		} else {
			flag = true;
		}
		return flag;
	}

	private String cellFormat(Cell cell) {
		String cellValue = "";
		// Check the cell type and format accordingly
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_NUMERIC:
			cellValue = Integer.toString((int) cell.getNumericCellValue());
			break;
		case Cell.CELL_TYPE_STRING:
			cellValue = cell.getStringCellValue();
			break;
		}
		return cellValue;
	}

	private String dateCellFormat(Cell cell) {
		String date = "";
		// Check the cell type and format accordingly
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_NUMERIC:
			date = new SimpleDateFormat("MM/dd/yyyy").format(DateUtil.getJavaDate(cell.getNumericCellValue()));
			break;
		case Cell.CELL_TYPE_STRING:
			date = cell.getStringCellValue();
			break;
		}
		return date;
	}

	@Override
	public int deleteAll(String fetchType) {
		if (fetchType.equals("sanctioned"))
			sdmDAO.sancdeleteAll();
		else
			sdmDAO.unsancdeleteAll();
		return 0;
	}

	public List<?> readCache(String fetchType) {
		List<SanctionedData> sancData = null;
		List<UnsanctionedData> unsancData = null;
		if (fetchType.equalsIgnoreCase("sanctioned")) {
			sancData = sdmDAO.fetchSancData();
			return sancData;
		} else {
			unsancData = sdmDAO.fetchUnsancData();
			return unsancData;
		}
	}

	public boolean checkDuplicateEntries(Data data, List<SanctionedData> sancData) {
		boolean flag = false;
		Stream<SanctionedData> sanction = sancData.stream().filter(p -> p.getPt_cust_id().equals(data.getPt_cust_id()));
		Iterator<SanctionedData> itsanc = sanction.iterator();
		while (itsanc.hasNext()) {
			SanctionedData data1 = itsanc.next();
			if ((data1.getApp_name()).equals(data.getApp_name()) && (data1.getPt_cust_id()).equals(data.getPt_cust_id())
					&& (data1.getStart_date()).equals(data.getStart_date())
					&& (data1.getEnd_date()).equals(data.getEnd_date())
					&& (data1.getApp_type()).equals(data.getApp_type())
					&& (data1.getIp_address_num()).equals(data.getIp_address_num())
					&& (data1.getIp_v6_address()).equals(data.getIp_v6_address())
					&& (data1.getCreate_date()).equals(data.getCreate_date())
					&& (data1.getPt_oper_id()).equals(data.getPt_oper_id())
					&& (data1.getIp_range()).equals(data.getIp_range())
					&& (data1.getIp_cidr()).equals(data.getIp_cidr()) && (data1.getWam_id()).equals(data.getWam_id())
					&& (data1.getApp_url()).equals(data.getApp_url())
					&& (data1.getIp_address()).equals(data.getIp_address())
					&& (data1.getHostname()).equals(data.getHostname())
					&& (data1.getContact_names()).equals(data.getContact_names())
					&& (data1.getDhcp_or_static()).equals(data.getDhcp_or_static())
					&& (data1.getEmail_address()).equals(data.getEmail_address())
					&& (data1.getPhone_number()).equals(data.getPhone_number())
					&& (data1.getNotes()).equals(data.getNotes()))
				flag = true;
		}
		return flag;
	}

	public boolean checkDuplicateEntries_unsanc(Data data, List<UnsanctionedData> unsancData) {
		boolean flag = false;
		Stream<UnsanctionedData> unsanction = unsancData.stream()
				.filter(p -> p.getPt_cust_id().equals(data.getPt_cust_id()));
		Iterator<UnsanctionedData> itsanc = unsanction.iterator();
		while (itsanc.hasNext()) {
			UnsanctionedData data1 = itsanc.next();
			if ((data1.getApp_name()).equals(data.getApp_name()) && (data1.getPt_cust_id()).equals(data.getPt_cust_id())
					&& (data1.getStart_date()).equals(data.getStart_date())
					&& (data1.getEnd_date()).equals(data.getEnd_date())
					&& (data1.getApp_type()).equals(data.getApp_type())
					&& (data1.getIp_address_num()).equals(data.getIp_address_num())
					&& (data1.getIp_v6_address()).equals(data.getIp_v6_address())
					&& (data1.getCreate_date()).equals(data.getCreate_date())
					&& (data1.getPt_oper_id()).equals(data.getPt_oper_id())
					&& (data1.getIp_range()).equals(data.getIp_range())
					&& (data1.getIp_cidr()).equals(data.getIp_cidr()) && (data1.getWam_id()).equals(data.getWam_id())
					&& (data1.getApp_url()).equals(data.getApp_url())
					&& (data1.getIp_address()).equals(data.getIp_address())
					&& (data1.getHostname()).equals(data.getHostname())
					&& (data1.getContact_names()).equals(data.getContact_names())
					&& (data1.getDhcp_or_static()).equals(data.getDhcp_or_static())
					&& (data1.getEmail_address()).equals(data.getEmail_address())
					&& (data1.getPhone_number()).equals(data.getPhone_number())
					&& (data1.getNotes()).equals(data.getNotes()))
				flag = true;
		}
		return flag;
	}
}