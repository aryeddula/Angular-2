/*
 * Copyright (c) 2000-2010 Wells Fargo.
 * 333 Market St, San Francisco, CA 94105 U.S.A.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Wells
 * Fargo bank. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Wells Fargo.
 */
package com.wellsfargo.service;
/*
 * Service
 * 
 * @Author: Ashok
 * @Version: 1.1
 * @Created on: 5/22/2017
 * 
 */
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;


public interface SDMService {
	
	
	//service method to fetch the sanc and unsanc data
	public List<?> fetchData(String fetchType);
	
	//service method to save the sanc and unsanc data
	public List<?> saveData(String fetchType,Map<String,String> map, String action);
	
	//service method to delete the sanc and unsanc data
	public void deleteData(String fetchType,Map<String,String> map,String action);
	
	//service method to load the sanc and unsanc data
	public int loadData(String fileType,String loadType,InputStream is) throws IOException;
	
	
	//service method to update the sanc and unsanc data
	public List<?> updateData(String fetchType,Map<String,String> map,String action);
	
	
	//service method to delete via daterange the sanc and unsanc data
	public int deleteDataViaDateRange(String fetchType,String stDate,String edDate);

	//Hard delete to delete test data
	public int deleteAll(String fetchType);
	
}
