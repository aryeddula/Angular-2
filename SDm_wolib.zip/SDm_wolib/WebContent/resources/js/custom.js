$( function() {
	$( "#tabs" ).tabs();
});
	  
var app = angular.module("sdmApp", []);
app.controller("sdmController", function ($scope) {	
	$scope.loadDataTemplate = "loadData.jsp";
	$scope.manageDataTemplate = "manageData.jsp";
	$scope.dateRangeTemplate = "dateRange.jsp";
	/* $scope.addDataTemplate = "addData.jsp"; */
});


function showAlertMessage(errMsg) {

	BootstrapDialog.show({
        type: BootstrapDialog.TYPE_DANGER,
        title: 'Error !',
        message: errMsg,
        buttons: [{ label: 'OK',
            action: function(dialogItself){
                dialogItself.close();
            }}]
	});
	
}

function loadData(event, form) {
	showSpinner();	
	event.preventDefault();
	var fileData=new FormData($(form)[0]);
	showSpinner();
    $.ajax({	      
        url			:$(form).attr("action"),
		type		:'POST',
		data		:fileData,
		// async :false,
		cache		:false,
		contentType	:false,
	    enctype		:'multipart/form-data',
		processData	:false,
		 timeout : 100000, 
        success : function(response) {
			console.log("SUCCESS: ", response);
			hideSpinner();
			display(response);
		},
		error : function(textstatus, ex) {
			if(textstatus.statusText == 'timeout') {
				console.log("Timedout:");
				hideSpinner();
				showtimeout(textstatus);
	        } else {
	        	console.log("ERROR: ", ex);
				hideSpinner();
				display(ex);
	        }

		}
    }); 
}




function manageData(event,fetchDataForm,fetchType) {
	showSpinner();
       $.ajax({   // for first time loading
       	url		: $(fetchDataForm).attr("action"),
       	type 	: 'POST',
       	datatype: "json",
       	data	: { 'fetchType': fetchType },
      	timeout 	: 100000,
          success : function(response) {
  			console.log("SUCCESS: ", response);
  			hideSpinner();
  			display(response);
  		},
  		error : function(ex) {
  			console.log("ERROR: ", ex);
  			hideSpinner();
  			display(ex); 
  		}
      });

	function display(response) {
		
		if(response.statusText == 'success'){
			
			$("#fetchedDataResults").show();
			
			var table = $('#fetchedDataResults').DataTable( {
				/* dom: "Bfrtip", */
		        bDestroy:true,
		        scrollY: "500px", 
		        scrollX: "600px",
		        bDeferRender:true,
		        bJqueryUI:true,
			    bAutoWidth: true,
			    processing:true,
			    responsive: true,
			    altEditor:true,
			    select:true,
			    fixedColumns:   {

		            leftColumns: 2

		        },
			    "rowCallback": function( row, data, index ) {
		    		if((fetchType == "unsanctioned")&& !(data.start_date == data.end_date)){
		    				 $('td', row).addClass('highlight'); 	
		    		}
			    },
			     "data": response.data,
				lengthMenu: [[50, 100, 200], [50, 100, 200]],
		        columns: [
		        	/* { data: "DT_RowId",visible:false }, */
		            { data: "ip_address_num" },
		            { data: "ip_v6_address" },
		            { data: "create_date" },
		            { data: "pt_cust_id" },
		            { data: "pt_oper_id" },
		            { data: "start_date" },
		            { data: "end_date" },
		            { data: "ip_range" },
		            { data: "ip_cidr" },
		            { data: "wam_id" },
		            { data: "app_url" },
		            { data: "app_name" },
		            { data: "app_type" },
		            { data: "ip_address" },
		            { data: "hostname" },
		            { data: "contact_names" },
		            { data: "dhcp_or_static" },
		            { data: "created_by" },
		            { data: "modified_by" },
		            { data: "email_address" },
		            { data: "phone_number"},
		            { data: "notes"}
		          /* { data: "status"} */


		        ],
			} );

			
			editor = new $.fn.dataTable.Editor( {  // for managing data
		         ajax:  { 
		         url		: 'manageData',
		         type 		: 'POST',
		         data		: {'fetchType': fetchType },
		         timeout 	: 100000,
		        },
		        table: "#fetchedDataResults",
		        fields: [/*
							 * { label: "ID:", name: "DT_RowId", visible:false },
							 */ {
		                label: "IP Address Number :",
		                name: "ip_address_num"
		            }, {
		                label: "IPv6 Address :",
		                name: "ip_v6_address"
		            }, {
		                label: "Create Date :",
		                name: "create_date",
		                type: 'datetime',
		            	format: 'MM/DD/YYYY'
		            }, {
		                label: "PT Cust.ID* :",
		                name: "pt_cust_id"
		            }, {
		                label: "PT Oper. ID* :",
		                name: "pt_oper_id"
		            }, {
		                label: "Start Date :",
		                name: "start_date",
		                type: 'datetime',
		            	format: 'MM/DD/YYYY'
		            }, {
		                label: "End Date :",
		                name: "end_date",
		                type: 'datetime',
		            	format: 'MM/DD/YYYY'
		            },{
		                label: "IP Range :",
		                name: "ip_range"
		            }, {
		                label: "IP CIDR :",
		                name: "ip_cidr"
		            }, {
		                label: "Wam Id* :",
		                name: "wam_id"
		            },{
		                label: "App. URL* :",
		                name: "app_url"
		            }, {
		                label: "App. Name* :",
		                name: "app_name"
		            }, {
		                label: "App. Type :",
		                name: "app_type"
		            }, {
		                label: "IP Address* :",
		                name: "ip_address"
		            },{
		                label: "Host Name* :",
		                name: "hostname"
		            },{
		                label: "Contact Names :",
		                name: "contact_names"
		            },{
		                label: "DHCP or STATIC :",
		                name: "dhcp_or_static"
		            },{
		                label: "Created By :", 
		                name: "created_by"
		            },{
		                label: "Modified By :",
		                name: "modified_by"
		            },{
		                label: "Email Address :",
		                name: "email_address"
		            },{
		                label: "Phone Number :",
		                name: "phone_number"
		            },{	
		                label: "Notes :",
		                name: "notes"
		            }    
		        ]
		    } );
	    // Display the buttons
			  // Display the buttons
			  new $.fn.dataTable.Buttons( table, [
			      { extend: "create", editor: editor, toolTip: "Create the New Entry" },
			      { extend: "edit",   editor: editor, toolTip: "Create the New Entry"  },
			      { extend: "remove",text:"Unsanc|Delete", editor: editor , toolTip: "If the selected row is sanctionedData then moves to unsactionedData. If the selected row is unsactionedData deletes the row permanently" },
			    /*
				 * { extend: "selectAll", editor: editor, toolTip: "selectAll" }, {
				 * extend: "selectNone", editor: editor, toolTip: "selectNone" },
				 */
			   /*
				 * { text: 'HardDelete', name: 'deleteall', toolTip:
				 * "HardDelete",// do not change name action: function ( e, dt,
				 * node, config ) {
				 * 
				 * bootbox.confirm({ title:'<strong
				 * style="color:#0000FF">DeleteAll</strong>', message: "Are you
				 * sure you want to delete all the row?", backdrop: true,
				 * buttons: { confirm: { label: 'DeleteAll', className:
				 * 'btn-primary' }, cancel: { label: 'Cancel', className:
				 * 'btn-danger' } }, callback: function (result) {
				 * 
				 * if(result == true){ showSpinner(); $.ajax({ url :
				 * 'manageData', type : 'POST', datatype: "json", data : {
				 * 'fetchType': fetchType,'action':'deleteall'}, timeout :
				 * 100000, success : function(response) { hideSpinner();
				 * bootbox.dialog({ title:'<strong
				 * style="color:#00804d">Successfully Deleted!</strong>',
				 * message: "Successfully Deleted"+" "+'<strong
				 * style="color:#00804d">'+response.count+'</strong>'+ " "
				 * +"rows from sanctioned", backdrop: true, buttons: {
				 * "success": { label: "Ok", className: "btn-success", callback:
				 * function () {} } } }); }, error : function(ex) {
				 * hideSpinner(); bootbox.dialog({ title:'<strong
				 * style="color:#FF0000">Error!</strong>', message: "Error
				 * occured during data deletion", backdrop: true, buttons: {
				 * "success": { label: "Ok", className: "btn-danger", callback:
				 * function () {} } } }); } }); } } }); } },
				 */
			      { extend: 'copy' },
			      { extend: 'excel' },
			      { extend: 'colvis' },
			      
			  ] );
		    table.buttons().container().appendTo( $('.col-sm-6:eq(0)', table.table().container() ) );
/*
 * table.on( 'select', function () { var selectedRows = table.rows( { selected:
 * true } ).count(); table.button( 1 ).enable( selectedRows === 1 ); } );
 */
		    editor.on( 'preSubmit', function ( e, o, action ) {
		    	 if ( action !== 'remove' ) {
		         	var ip_v6_address = editor.field('ip_v6_address');
		         	var re = new RegExp('^((?:[0-9A-Fa-f]{1,4}(?::[0-9A-Fa-f]{1,4})*)?)::((?:[0-9A-Fa-f]{1,4}(?::[0-9A-Fa-f]{1,4})*)?)$');
		        
		         	if (!re.test(ip_v6_address.val()) && ip_v6_address.val()) {
		             	 ip_v6_address.error( 'Enter valid IPV6 Address' ); 
		              }
		         	
		         	 var ip_address = editor.field( 'ip_address' );
		             
		             // Only validate user input values - different values
						// indicate that
		             // the end user has not entered a value
		             if ( ! ip_address.isMultiValue() ) {
		                 if ( ! ip_address.val() && ip_address.val("")) {
		                 	ip_address.error( 'IP Address must be given' );
		                 }
		                  
		                 if ( ip_address.val().length >= 20 ) {
		                 	ip_address.error( 'The IP Address length must be less that 20 characters' );
		                 }
		             }
		             var wam_id = editor.field( 'wam_id' );
		             
		             // Only validate user input values - different values
						// indicate that
		             // the end user has not entered a value
		             if ( ! wam_id.isMultiValue() ) {
		                 if ( ! wam_id.val() && wam_id.val("")) {
		                 	wam_id.error( 'Wam Id must be given' );
		                 }                               
		             }
		             
		             var app_name = editor.field( 'app_name' );
		             
		             // Only validate user input values - different values
						// indicate that
		             // the end user has not entered a value
		             if ( ! app_name.isMultiValue() ) {
		                 if ( ! app_name.val() ) {
		                 	app_name.error( 'App. name must be given' );
		                 }                               
		             }
		             
		             var host_name = editor.field( 'hostname' );
		             
		             // Only validate user input values - different values
						// indicate that
		             // the end user has not entered a value
		             if ( ! host_name.isMultiValue() ) {
		                 if ( ! host_name.val() && host_name.val() ) {
		                 	host_name.error( 'Host name must be given' );
		                 }                               
		             }
		             
		             var app_url = editor.field( 'app_url' );
		             
		             // Only validate user input values - different values
						// indicate that
		             // the end user has not entered a value
		             if ( ! app_url.isMultiValue() ) {
		                 if ( ! app_url.val() && app_url.val("")) {
		                 	app_url.error( 'App. URL must be given' );
		                 }                               
		             }
		             
		             var pt_oper_id = editor.field( 'pt_oper_id' );
		             
		             // Only validate user input values - different values
						// indicate that
		             // the end user has not entered a value
		             if ( ! pt_oper_id.isMultiValue() ) {
		                 if ( ! pt_oper_id.val() && pt_oper_id.val("")) {
		                 	pt_oper_id.error( 'PT Oper. ID must be given' );
		                 }                               
		             }
		             
		             var pt_cust_id = editor.field( 'pt_cust_id' );
		             
		             // Only validate user input values - different values
						// indicate that
		             // the end user has not entered a value
		             if ( ! pt_cust_id.isMultiValue() ) {
		                 if ( ! pt_cust_id.val() && pt_cust_id.val("")) {
		                 	pt_cust_id.error( 'PT Cust. ID must be given' );
		                 }                               
		             }
		         
		             if ( this.inError() ) {
		                 return false;
		             }
		         }
		    });
		}
		else{
			showAlertMessage('Sorry, no results found. Possible issues could be either Invalid data or Backend connection failure.');
		}
	}
} 

function showSpinner() {
	$("#modal").css("display","block");
	$("#fade").css("display","block");
}

function hideSpinner() {
	$("#modal").css("display","none");
	$("#fade").css("display","none");
}
function dateRange(event,dateRangeForm,fetchType,status,stDate,edDate) {
	event.preventDefault();
	showSpinner();
    $.ajax({	      
        url			:$(dateRangeForm).attr("action"),
		type		:'POST',
		data		:{ 'fetchType': fetchType,'stDate':stDate ,'edDate':edDate},
		timeout 	: 100000,
        success : function(response) {
			console.log("SUCCESS: ", response);
			hideSpinner();
			show(response);
		},
		error : function(textstatus,ex) {
			if(textstatus.statusText == 'timeout') {
				console.log("Timedout:");
				hideSpinner();
				lookup(textstatus);
	        } else {
				console.log("ERROR: ", ex);
				hideSpinner();
				show(ex); 
	        }


		}
    }); 
}

function display(response) {
	response = JSON.parse(response);
	if(response.statusText == 'success'){
		$("#erroralert").hide();
		$("#infoalert").hide();
		$("#successalertmessage").html(response.message);
		$("#successalert").show();	
	}else if(response.statusText == 'info'){	
		$("#successinlinealert").hide();
		$("#errorinlinealert").hide();
		$("#infoalertmessage").html(response.message);	
		$("#infoalert").show();
	}else if(response.statusText == 'error'){	
		$("#successalert").hide();
		$("#infoalert").hide();
		$("#erroralertmessage").html($.parseHTML( response.message));
		$("#erroralert").show();		
	}	
}
function showtimeout(textstatus) {
	if(textstatus.statusText == 'timeout'){	
		$("#successinlinealert").hide();
		$("#errorinlinealert").hide();
		$("#infoalert").hide();
		$("#timeoutalertmessage").html('Request Timedout:'+'The timedout requests will be running in the background the updated data in the datatables will be shownup after few minutes');	
		$("#timeoutalert").show();	
	}
}

function lookup(textstatus) {
	if(textstatus.statusText == 'timeout'){	
		$("#successinlinealert").hide();
		$("#errorinlinealert").hide();
		$("#infoalert").hide();
		$("#timeoutalertmessagedatarange").html('Request Timedout:'+'The timedout requests will be running in the background the updated data in the datatables will be shownup after few minutes');	
		$("#timeoutalertdatarange").show();	
	}
}
function show(response) {
	response = JSON.parse(response);
	if(response.statusText == 'success'){
		$("#infoinlinealert").hide();
		$("#errorinlinealert").hide();
		$("#successinlinealertmessage").html(response.message);	
		$("#successinlinealert").show();		
	}else if(response.statusText == 'info'){	
		$("#successinlinealert").hide();
		$("#errorinlinealert").hide();
		$("#infoinlinealertmessage").html($.parseHTML(response.message));	
		$("#infoinlinealert").show();			
	}else if(response.statusText == 'error'){	
		$("#successinlinealert").hide();
		$("#infoinlinealert").hide();
		$("#errorinlinealertmessage").html($.parseHTML(response.message));
		$("#errorinlinealert").show();		
	}	
}

// Jquery validation==========================================

/* file upload */
!function(e){
	var t=function(t,n){
		this.$element=e(t),
		this.type=this.$element.data("uploadtype")||(this.$element.find(".thumbnail").length>0?"image":"file"),
		this.$input=this.$element.find(":file");
		if(this.$input.length===0)return;
		this.name=this.$input.attr("name")||n.name,this.$hidden=this.$element.find('input[type=hidden][name="'+this.name+'"]'),
		this.$hidden.length===0&&(this.$hidden=e('<input type="hidden" />'),
		this.$element.prepend(this.$hidden)),
		this.$preview=this.$element.find(".fileupload-preview");
		var r=this.$preview.css("height");
		this.$preview.css("display")!="inline"&&r!="0px"&&r!="none"&&this.$preview.css("line-height",r),
		this.original={exists:this.$element.hasClass("fileupload-exists"),preview:this.$preview.html(),hiddenVal:this.$hidden.val()},
		this.$remove=this.$element.find('[data-dismiss="fileupload"]'),
		this.$element.find('[data-trigger="fileupload"]').on("click.fileupload",e.proxy(this.trigger,this)),
		this.listen()};
		t.prototype={listen:function(){this.$input.on("change.fileupload",e.proxy(this.change,this)),
		e(this.$input[0].form).on("reset.fileupload",e.proxy(this.reset,this)),
		this.$remove&&this.$remove.on("click.fileupload",e.proxy(this.clear,this))},
		change:function(e,t){if(t==="clear")return;
		var n=e.target.files!==undefined?e.target.files[0]:e.target.value?{name:e.target.value.replace(/^.+\\/,"")}:null;
		if(n&&n.size <= 7989){showAlertMessage('Selected file cannot be empty !');this.clear();return}
		if(n&&n.size  > 122880){showAlertMessage('Selected file cannot exceed more than 120 kb !');this.clear();return}
		if(!n){this.clear();return}this.$hidden.val(""),this.$hidden.attr("name",""),this.$input.attr("name",this.name);
		if(this.type==="image"&&this.$preview.length>0&&(typeof n.type!="undefined"?n.type.match("image.*"):n.name.match(/\.(gif|png|jpe?g)$/i))&&typeof FileReader!="undefined"){var r=new FileReader,			
		i=this.$preview,s=this.$element;r.onload=function(e){i.html('<img src="'+e.target.result+'" '+(i.css("max-height")!="none"?'style="max-height: '+i.css("max-height")+';"':"")+" />"),s.addClass("fileupload-exists").removeClass("fileupload-new")},r.readAsDataURL(n)}else this.$preview.text(n.name),this.$element.addClass("fileupload-exists").removeClass("fileupload-new")},clear:function(e){this.$hidden.val(""),this.$hidden.attr("name",this.name),this.$input.attr("name","");if(navigator.userAgent.match(/msie/i)){var t=this.$input.clone(!0);this.$input.after(t),this.$input.remove(),this.$input=t}else this.$input.val("");this.$preview.html(""),this.$element.addClass("fileupload-new").removeClass("fileupload-exists"),e&&(this.$input.trigger("change",["clear"]),e.preventDefault())},reset:function(e){this.clear(),this.$hidden.val(this.original.hiddenVal),this.$preview.html(this.original.preview),this.original.exists?this.$element.addClass("fileupload-exists").removeClass("fileupload-new"):this.$element.addClass("fileupload-new").removeClass("fileupload-exists")},trigger:function(e){this.$input.trigger("click"),e.preventDefault()}},e.fn.fileupload=function(n){return this.each(function(){var r=e(this),i=r.data("fileupload");i||r.data("fileupload",i=new t(this,n)),typeof n=="string"&&i[n]()})},e.fn.fileupload.Constructor=t,e(document).on("click.fileupload.data-api",'[data-provides="fileupload"]',function(t){var n=e(this);if(n.data("fileupload"))return;n.fileupload(n.data());var r=e(t.target).closest('[data-dismiss="fileupload"],[data-trigger="fileupload"]');r.length>0&&(r.trigger("click.fileupload"),
		t.preventDefault())})}(window.jQuery)

